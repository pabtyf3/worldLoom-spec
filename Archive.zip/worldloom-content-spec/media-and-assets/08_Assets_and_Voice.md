# Assets

Audio, images, voice supported at schema level.
