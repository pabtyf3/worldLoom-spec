# Core Schemas

```ts
interface StoryBundle {
  id: string
  version: string
  world: WorldDefinition
  storyGraph: StoryGraph
}
```
