# Save Game

```ts
interface SaveGame {
  currentScene: string
}
```
