# Scene System

```ts
interface Scene {
  id: string
  narrative: NarrativeBlock
  exits?: Exit[]
}
```
