# Lore System

Non-executable world knowledge.
