# Rules System

```ts
interface RuleModule {
  resolveAction(): void
}
```
