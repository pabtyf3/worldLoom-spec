# Core Vision & Principles

Narrative-first, schema-driven, offline-capable RPG engine.
Narrative is the primary artifact; rules and systems interpret it.
