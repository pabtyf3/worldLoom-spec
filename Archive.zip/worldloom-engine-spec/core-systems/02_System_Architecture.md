# System Architecture

Layers:
- Presentation
- Engine Core
- Data
- (Future) AI

Strict separation of concerns enforced.
