# MVP Scope

Includes core runtime only.
