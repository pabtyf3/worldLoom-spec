# worldLoom Canonical Specification  
## Addendum: Implicit Design Decisions & Outstanding Gaps

---

## 28. Topics Discussed but Not Yet Explicitly Captured

This addendum records important design decisions that were discussed implicitly or tangentially, but not yet stated clearly in the core spec or prior addenda.  
These items primarily **constrain system shape**, rather than adding new features.

---

### 28.1 Event & Telemetry System (Quiet but Important)

The engine emits **structured events**, not just narrative progression.

Events discussed include:

- Scene entry / exit  
- Action selection  
- Ruleset resolution  
- World or state mutation  

Originally framed as:

- Debugging aid  
- Replay / rewind capability  
- Future AI training signal  

**Why this matters:**

- Defines runtime contracts  
- Shapes the engine API  
- Enables AI observability later  

**Spec implication:**

> A canonical **event schema** is likely required, even if minimally used in Phase 1.

---

### 28.2 Save / Resume / Deterministic Replay

Strongly implied by:

- Offline-first operation  
- Hands-free play  
- Mobile expansion  
- Async / AI-assisted generation  

Key idea discussed:

> If execution is deterministic, state snapshots are cheap and reliable.

This impacts:

- State serialization format  
- Versioning strategy  
- Backward compatibility guarantees  

---

### 28.3 Partial Automation & Asynchronous Generation

Discussed concepts include:

- AI preparing future scenes while the player is in the current one  
- Narrative buffers  
- Non-blocking generation  

Even without AI (Phase 1), this implies:

- Clear scene boundaries  
- Stateless scene definitions  
- Predictable transitions  

This reinforces earlier architectural decisions but warrants explicit mention.

---

### 28.4 Accessibility Beyond Audio

Accessibility was discussed implicitly through:

- Hands-free design  
- Audio-first play  
- Simplified interaction  

Not yet explicitly stated:

- Dyslexia-friendly text modes  
- Adjustable verbosity  
- Reduced cognitive-load modes  

These affect:

- Presentation profiles  
- Scene narration variants  
- Player configuration options  

---

### 28.5 Internationalization & Localization (Light Touch)

Mentioned indirectly via:

- Audio replacement  
- Pre-recorded assets  
- Voice packs  

Minimum implications:

- Language-neutral IDs  
- No hardcoded prose assumptions  

Flagging this early ensures schemas do not block localization later.

---

### 28.6 Asset Abstraction Beyond Audio

While audio was the primary focus, discussions also included:

- Future graphical layers  
- Tile-based or visual representations  
- Descriptive → visual projection  

This reinforces:

- Abstract asset references  
- No engine assumptions about output modality  

Even if not Phase 1, the schema must remain flexible.

---

### 28.7 Studio as a Teaching Tool (Pedagogical Angle)

Repeatedly discussed themes:

- Teaching narrative structure  
- Helping new writers learn interactive storytelling  
- Studio AI acting as mentor/editor  

This is not marketing — it informs:

- Validation messaging  
- AI feedback tone  
- Studio UX expectations  

---

## 29. Why These Matter *Now* (Not Later)

All of the above share a critical property:

> They **constrain system shape** without adding surface features.

If ignored now:

- Schemas harden prematurely  
- Studio accumulates ad-hoc flags  
- Engine emits unstructured noise  
- Future AI lacks clean training data  

Encoding them early costs little and avoids months of refactoring later.

---

## 30. Final “Did We Miss Anything?” Checklist

Use this checklist as a safety net.  
If every item has at least a headline in the spec, the foundation is sound.

---

### Core System

- StoryBundle as atomic unit  
- World / Scene / Location separation  
- Deterministic execution  
- Validation-first runtime  

### Rules & Mechanics

- Ruleset abstraction  
- D&D SRD / OpenD6 as examples  
- Ruleset isolation from narrative  

### Studio

- Authoring environment  
- Prose converter  
- AI assistant (bounded role)  
- Teaching / mentoring aspect  

### Presentation & Media

- Presentation profiles  
- Audio strategies  
- Player-side output selection  
- Multi-market publishing  

### Accessibility & Markets

- Hands-free / audio-first  
- Children’s content  
- Educational usage  
- Accessibility variants  

### Runtime Infrastructure

- Event / telemetry schema  
- Save / resume / replay model  
- Localization readiness  
- Asset abstraction (non-audio)  

### AI (Future-Proofing)

- Training data shape  
- Hybrid AI approach  
- Studio → AI DM continuity  

> The unchecked items represent **small, well-defined, and safe** next additions.

---

*End of addendum.*
