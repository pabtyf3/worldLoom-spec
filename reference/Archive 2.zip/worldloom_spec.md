# worldLoom Canonical Specification

**v1.0 — Headline Baseline (Reconstructed)**

---

## 1. Purpose & Vision

**worldLoom** is a narrative-first interactive fiction engine designed to:

- Execute deterministic, rules-driven stories  
- Support human-authored content at scale  
- Prepare structured narrative data suitable for on-device AI DM use  
- Remain predominantly offline-capable as a core differentiator  

**Phase 1 delivers:**

- A web-based interactive fiction engine  
- A creator (studio) app  
- Canonical story/world formats  
- Validation-first execution  

Later phases extend this foundation to mobile and AI DM functionality.

---

## 2. Core Architectural Principles

- **Spec-first:** All behavior derives from canonical schemas  
- **Deterministic runtime:** Same inputs → same outcomes  
- **Structured narrative:** No freeform blobs  
- **Validation everywhere:** Invalid content never executes  
- **Separation of concerns:**  
  - Spec ≠ Engine ≠ Studio ≠ Content ≠ AI  

---

## 3. Canonical Content Model (StoryBundle)

The **StoryBundle** is the atomic unit of execution and distribution.

A StoryBundle contains:

- Metadata  
- Ruleset declaration  
- World definition  
- Narrative content  
- Assets (references only)  
- Entry points  

StoryBundles are:

- Versioned  
- Self-contained  
- Fully validatable  
- Ruleset-aware  

---

## 4. World & Narrative Structure

### 4.1 World

A **World** defines:

- Locations (spatial and conceptual)  
- Lore  
- Factions  
- Characters / NPCs  
- Items  
- Global state variables  

Worlds are static definitions; runtime state is separate.

---

### 4.2 Locations

Locations represent player-observable contexts, not just geography.

**Supported types:**

- Town / Settlement  
- Wilderness  
- Dungeon  
- Interior  
- Camp  
- Other / Abstract  

**Key insight:**

> Locations may be conceptual or investigative, not purely spatial  
> (e.g. examining a coat, a crime scene detail, a confined interaction space)

**Topography support:**

- Optional sub-areas  
- Descriptive spatial metadata  
- Narrative affordances rather than strict coordinates  

---

### 4.3 Scenes

Scenes are the primary execution unit.

A **Scene** defines:

- Narrative presentation  
- Available actions  
- Conditions  
- Transitions  
- Effects on world state  

Scenes:

- Belong to a Location  
- Are deterministic  
- Do not execute arbitrary logic  

---

## 5. Runtime Execution Model

**High-level flow:**

1. Load StoryBundle  
2. Validate against spec + ruleset  
3. Initialize world + player state  
4. Enter scene loop:  
   - Present scene  
   - Accept player intent  
   - Validate intent  
   - Resolve via ruleset  
   - Apply effects  
   - Emit structured events  
   - Transition or conclude  

**Errors are:**

- Structured  
- Non-fatal where possible  
- Explicitly reported  

---

## 6. Ruleset System (Extensibility — Key Design Area)

### 6.1 Ruleset Abstraction

A **Ruleset** defines:

- Character attributes  
- Action resolution  
- Randomness mechanics  
- Combat (if applicable)  
- Skill checks  
- Resource systems  

Rulesets are:

- Declared by StoryBundle  
- Pluggable  
- Isolated from narrative content  

---

### 6.2 Ruleset Interface (Conceptual)

Rulesets expose:

- State schema  
- Action validators  
- Resolution functions  
- Outcome schemas  

The engine:

- Does not know D&D, OpenD6, etc.  
- Only calls the ruleset contract  

---

### 6.3 Reference Implementations (Planned)

Ruleset extensibility allows:

- D&D SRD  
- OpenD6  

as **examples**, not hardcoded assumptions.

This enables:

- Custom lightweight systems  
- Genre-specific mechanics  
- AI DM compatibility later  

---

## 7. Studio (Creator App)

### Purpose

The Studio is a guided authoring environment, not a game engine.

**Goals:**

- Make correct content easy  
- Make incorrect content hard or impossible  
- Teach the spec implicitly  

### Capabilities

- World editor (locations, lore, factions)  
- Scene editor  
- Action definition  
- Ruleset selection  
- Validation feedback  
- Export StoryBundles  

> Studio never executes stories — it authors them.

---

## 8. Audio, Voice & Presentation

### 8.1 Voice & Audio

- Text-first system  
- Optional voice layer  
- Voice is presentation, not logic  

**Planned characteristics:**

- Scene narration via TTS  
- Character voice differentiation  
- Offline-capable voice where possible  
- Swappable providers  

---

### 8.2 Hands-off / Ambient Play

**Key vision point:**

- Car-friendly  
- Audio-first play  
- Minimal interaction loops  
- Narration-driven pacing  

This influences:

- Scene chunking  
- Action granularity  
- Deterministic flow (critical for async narration)  

---

## 9. AI Integration (Future, but Designed For)

AI is **not required** for Phase 1 execution.

Phase 1 prepares for Phase 3 by:

- Enforcing structured outputs  
- Using consistent schemas  
- Avoiding freeform narrative blobs  

**Planned AI DM model:**

- Small, quantized, on-device  
- Fine-tuned, not trained from scratch  

**Hybrid approach:**

- Template-driven structure  
- AI-generated flavor text  

---

## 10. Public Domain Content Strategy

Public domain works are used to:

- Seed initial content  
- Provide examples  
- Train AI on expected formats  

**Key points:**

- Not direct retellings  
- Adjacent or parallel stories  
- Same worlds, new protagonists  
- Respect narrative structure, not prose copying  

**Examples discussed:**

- Sherlock Holmes (investigation, observation)  
- Gothic / adventure works  
- Strong location- and lore-heavy stories  

---

## 11. Validation & Tooling

Validation is a **core system**, not an afterthought.

- Schema validation  
- Cross-reference validation  
- Ruleset validation  
- Studio-integrated feedback  
- Engine-enforced rejection of invalid content  

---

## 12. What This Spec Is (and Is Not)

**This spec is:**

- An implementation baseline  
- A contract  
- A stabilizing force  

**This spec is not:**

- Final prose  
- A UX design doc  
- An AI prompt playground  
