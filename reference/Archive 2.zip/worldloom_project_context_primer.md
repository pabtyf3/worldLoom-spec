# worldLoom — Project Context Primer

> **Purpose of this document**  
> This file is a **conversation primer**.  
> It is designed to be dropped into a new chat (human or AI) to rapidly establish shared context about the **worldLoom project**, its goals, and its non‑negotiable design decisions.

This is **not** the full spec.  
It is a **map, orientation layer, and set of guardrails**.

---

## 1. What worldLoom Is

**worldLoom** is a **narrative-first, deterministic interactive fiction system**.

At its core, it is:

- A structured storytelling engine  
- A schema-driven narrative format  
- A creator Studio for authoring valid content  
- A publishing pipeline for multiple media formats  
- A foundation for future AI-assisted storytelling  

worldLoom is explicitly **not**:

- A freeform AI storytelling sandbox  
- A runtime-driven improvisational DM  
- A single-market game engine  

---

## 2. Core Design Pillars (Non-Negotiable)

These ideas appear everywhere in the spec and should be assumed unless explicitly stated otherwise.

### 2.1 Determinism

- Same inputs → same outcomes  
- Enables:
  - Offline-first play  
  - Save / resume / replay  
  - Hands-free audio  
  - Async / AI-assisted generation  

### 2.2 Spec-First Architecture

- All behavior derives from schemas  
- Validation precedes execution  
- Invalid content never runs  

### 2.3 Separation of Concerns

- **Spec ≠ Engine ≠ Studio ≠ Content ≠ AI**
- Narrative logic is not presentation
- AI assists authoring, not runtime execution

---

## 3. Canonical Content Model (Headline)

### 3.1 StoryBundle

The **StoryBundle** is the atomic unit of distribution and execution.

A StoryBundle contains:

- Metadata (including age profile)
- Ruleset declaration
- World definition
- Narrative content (scenes)
- Asset references
- Entry points

StoryBundles are:

- Versioned
- Self-contained
- Fully validatable
- Ruleset-aware

---

## 4. World, Narrative & Knowledge

### 4.1 World

The **World** is a static definition containing:

- Locations (spatial *and* conceptual)
- Characters & NPCs
- Factions
- Items
- Global state variables
- **Lore (explicit subsystem)**

Runtime state is separate.

### 4.2 Scenes

Scenes are the **primary execution unit**.

Scenes:

- Belong to a location
- Present narrative
- Offer actions
- Apply deterministic effects
- Transition explicitly

They do **not** execute arbitrary logic.

### 4.3 Lore (First-Class, Inside World)

Lore is:

- Structured knowledge
- Addressable by ID
- Revealable / discoverable
- Referenceable by scenes, actions, factions, companions

Lore unlocks:

- Actions
- Scene branches
- Dialogue
- Investigative progression

---

## 5. Rulesets & Mechanics

Rulesets are **pluggable and isolated**.

A Ruleset defines:

- Attributes
- Action validation
- Resolution mechanics
- Randomness (if any)
- Outcome schemas

The engine:

- Knows nothing about D&D, OpenD6, etc.
- Only calls the ruleset contract

---

## 6. Studio (Creator App)

The **Studio** is a guided authoring environment.

It is:

- A world editor
- A narrative structuring tool
- A prose converter
- A spec tutor
- An AI-assisted authoring environment

It is **not**:

- A runtime
- A game engine
- A freeform AI playground

---

## 7. Studio AI (Bounded Role)

Studio AI is an **authoring assistant**, not a DM.

It may:

- Draft scenes, lore, NPCs
- Refactor prose into structured narrative
- Suggest transitions and actions
- Enforce spec compliance

It must:

- Respect schema constraints
- Respect age profiles
- Refuse prohibited content
- Produce reviewable drafts only

---

## 8. Prose Conversion Pipeline

Existing prose can be imported and mapped into worldLoom.

Pipeline (conceptual):

```
Raw Prose
 → Structural Analysis
 → World & Narrative Extraction
 → Spec-Constrained Conversion
 → Editable StoryBundle Draft
```

Key principle:

> The AI does not “understand the story” — it maps prose into spec-defined affordances.

Imported prose is treated as **untrusted input**.

---

## 9. Multi-Market & Presentation Model

worldLoom is **multi-market by design**.

The same StoryBundle can project to:

- Interactive games
- Audiobooks
- Children’s books
- Educational modules
- Accessibility-first experiences
- Hands-free / in-car audio

### 9.1 Presentation Profiles

Presentation is a **first-class concept**, separate from logic.

Profiles define:

- Target medium
- Interaction level
- Audio strategy
- Pacing constraints

Examples:

- `interactive-game`
- `audiobook-linear`
- `bedtime-story`
- `educational-guided`
- `handsfree-audio`

---

## 10. Audio & Media

Audio is **abstracted**, not hardcoded.

Supported strategies include:

- TTS
- Pre-recorded voice
- Hybrid approaches
- Silent / text-only
- Accessibility-enhanced narration

Voice is metadata (tone, age range, register), not a binding decision.

---

## 11. Companions, Relationships & Romance

### 11.1 Companions

Companions are:

- Characters with state
- Relationship variables
- Rule-bound agency

They are **not AI DMs**.

### 11.2 Relationships & Romance

Romance is:

- A specialization of relationship mechanics
- Not a separate engine system

Same primitives support:

- Friendship
- Trust
- Rivalry
- Romance
- Betrayal

Tone and availability are controlled by **age profiles**.

---

## 12. Multiplayer (Scoped, Optional)

Multiplayer is:

- Optional
- Not foundational
- Treated as a session orchestration layer

It must:

- Preserve determinism
- Avoid real-time twitch assumptions
- Support async / shared decisions

---

## 13. Accessibility & Education

Accessibility is structural, not cosmetic.

Supported concepts include:

- Hands-free play
- Audio-first consumption
- Adjustable verbosity
- Reduced cognitive load modes
- Educational annotations

---

## 14. Age Ranges & Content Safety (Critical)

### 14.1 Age Profiles

Every project declares an **Age Profile** at creation.

Examples:

- `early-childhood` (2–6)
- `children` (7–12)
- `young-teen` (13–15)
- `teen` (16–17)
- `adult` (18+)

Age Profiles are:

- Embedded in StoryBundle metadata
- Enforced by schema + Studio
- **Immutable once content exists**

### 14.2 Absolute Prohibitions

Some content has **no valid age range**.

This content:

- Cannot be authored
- Cannot be generated
- Cannot be imported
- Cannot be overridden

Enforcement is structural (schema + validation), not moderation.

---

## 15. Events, Replay & Future AI

The engine emits **structured events**:

- Scene entry / exit
- Action selection
- Resolution
- State mutation

This enables:

- Debugging
- Deterministic replay
- Observability
- Future AI training signals

---

## 16. What This Context Is For

When starting a new chat, this document establishes:

- The architectural philosophy
- The safety model
- The authoring constraints
- The long-term vision

Questions, designs, or proposals should:

- Respect determinism
- Respect schema-first validation
- Respect age locking & safety
- Avoid runtime AI improvisation
- Preserve multi-market flexibility

---

## 17. Canonical Spec Location

The authoritative specification lives in a **read-only repository**:

```
./WorldLoom-Spec/
```

### Proposed structure:

```
WorldLoom-Spec/
├─ core/
│  ├─ WORLDLOOM_SPEC.md
├─ studio/
│  ├─ STUDIO_AI.md
│  ├─ PROSE_CONVERTER.md
├─ presentation/
│  ├─ PRESENTATION_PROFILES.md
│  ├─ AUDIO_SYSTEM.md
├─ narrative/
│  ├─ LORE.md
│  ├─ COMPANIONS_RELATIONSHIPS.md
├─ safety/
│  ├─ AGE_PROFILES.md
│  ├─ AGE_PROFILE_LOCKING.md
│  ├─ ABSOLUTE_PROHIBITIONS.md
│  ├─ CONTENT_AUDIT_RULES.md
├─ runtime/
│  ├─ EVENTS_AND_REPLAY.md
│  ├─ SESSION_MODEL.md
```

This file is intentionally **lighter than the spec** but **stricter than a pitch**.

---

**End of context primer.**
